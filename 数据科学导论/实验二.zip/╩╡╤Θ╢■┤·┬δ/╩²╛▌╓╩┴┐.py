import pandas as pd

# 从 'salaries.csv' 文件中读取数据到 pandas DataFrame
File_path = 'salaries.csv'
data_set = pd.read_csv(File_path, index_col=0)
# 检查缺失值及其数量
missing_values = data_set.isnull()
missing_counts = missing_values.sum()
print(missing_values)
print(missing_counts)

# 删除含有缺失值的行，并将缺失的 'salary' 列用均值填充
data_set.dropna(axis=0, inplace=True)
data_set['salary'].fillna(data_set['salary'].mean(), inplace=True)
print(data_set)

#处理异常值

# 基于特定条件和列值过滤数据
data_set = data_set[(data_set['yrs.since.phd'] <= 60) & (data_set['yrs.service'] <= 60)]
data_set = data_set[data_set['yrs.since.phd'] >= data_set['yrs.service']]
data_set = data_set[(data_set['sex'] == 'Male') | (data_set['sex'] == 'Female')]
print(data_set)
print(data_set['yrs.service'] == data_set['yrs.since.phd'])

# 进一步清洗数据和处理特定条件
data_set = data_set[(data_set['yrs.since.phd'] <= 60) & (data_set['yrs.service'] <= 60)]
for i in range(len(data_set)):
    if (data_set.iloc[i, 2] < data_set.iloc[i, 3]):
        data_set.iloc[i, 2] = data_set.iloc[i, 3]
    if ((data_set.iloc[i, 4] != 'Male') & (data_set.iloc[i, 4] != 'Female')):
        data_set.iloc[i, 4] = 'Male'

print(data_set)
