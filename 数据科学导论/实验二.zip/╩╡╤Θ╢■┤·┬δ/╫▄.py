import pandas as pd

# 从 'salaries.csv' 文件中读取数据到 pandas DataFrame
File_path = 'salaries.csv'
data_set = pd.read_csv(File_path, index_col=0)

# 获取数据集的样本数量和属性数量
sample_size = len(data_set)
num_attributes = len(data_set.columns)

# 打印样本数量和属性数量
print('样本数量:', sample_size)
print('属性数量:', num_attributes)

# 显示数据集的信息、汇总统计和前几行数据
data_info = data_set.info()
data_describe = data_set.describe()
print(data_describe)
head_data = data_set.head()
first_five_value = data_set.iloc[:5]
print(head_data)
print(first_five_value)

# 访问倒数第二行第三列的特定数值
value = data_set.iloc[-2, 2]
print('特定数值:', value)

# 检查缺失值及其数量
missing_values = data_set.isnull()
missing_counts = missing_values.sum()
print(missing_values)
print(missing_counts)

# 删除含有缺失值的行，并将缺失的 'salary' 列用均值填充
data_set.dropna(axis=0, inplace=True)
data_set['salary'].fillna(data_set['salary'].mean(), inplace=True)
print(data_set)

# 根据不同条件过滤和查询数据集
print(data_set.loc[1])
print(data_set['salary'] > 190000)
print(data_set[data_set['salary'] > 190000])
print(data_set[data_set['yrs.service'] == 60])
print(data_set[data_set['yrs.since.phd'] >= data_set['yrs.service']])

# 基于特定条件和列值过滤数据
data_set = data_set[(data_set['yrs.since.phd'] <= 60) & (data_set['yrs.service'] <= 60)]
data_set = data_set[data_set['yrs.since.phd'] >= data_set['yrs.service']]
data_set = data_set[(data_set['sex'] == 'Male') | (data_set['sex'] == 'Female')]
print(data_set)
print(data_set['yrs.service'] == data_set['yrs.since.phd'])

# 进一步清洗数据和处理特定条件
data_set = data_set[(data_set['yrs.since.phd'] <= 60) & (data_set['yrs.service'] <= 60)]
for i in range(len(data_set)):
    if (data_set.iloc[i, 2] < data_set.iloc[i, 3]):
        data_set.iloc[i, 2] = data_set.iloc[i, 3]
    if ((data_set.iloc[i, 4] != 'Male') & (data_set.iloc[i, 4] != 'Female')):
        data_set.iloc[i, 4] = 'Male'

print(data_set)

# 分析特定数据子集并生成汇总统计
new_teacher = data_set[data_set['yrs.service'] == 0]
print(len(new_teacher))
print(data_set.describe())
data_set_A = data_set[data_set['discipline'] == 'A']
print(data_set_A.describe())
data_set_B = data_set[data_set['discipline'] == 'B']
print(data_set_B.describe())

# 使用饼图展示学科 A 和 B 之间的平均工资差异
import matplotlib.pyplot as plt

plt.figure(figsize=(8, 4))
plt.pie([data_set_A['salary'].mean(), data_set_B['salary'].mean()], labels=['A', 'B'])
plt.show()

# 使用饼图展示男性和女性教师之间的平均工资差异
data_set_Male = data_set[data_set['sex'] == 'Male']
data_set_Female = data_set[data_set['sex'] == 'Female']
plt.pie([data_set_Male['salary'].mean(), data_set_Female['salary'].mean()], labels=['Male', 'Female'])
plt.show()
