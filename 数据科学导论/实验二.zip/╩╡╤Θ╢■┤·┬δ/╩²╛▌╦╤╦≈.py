import pandas as pd

# 从 'salaries.csv' 文件中读取数据到 pandas DataFrame
File_path = 'salaries.csv'
data_set = pd.read_csv(File_path, index_col=0)
# 分析特定数据子集并生成汇总统计
new_teacher = data_set[data_set['yrs.service'] == 0]
print(len(new_teacher))
print(data_set.describe())
data_set_A = data_set[data_set['discipline'] == 'A']
print(data_set_A.describe())
data_set_B = data_set[data_set['discipline'] == 'B']
print(data_set_B.describe())
