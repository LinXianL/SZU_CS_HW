import pandas as pd

# 从 'salaries.csv' 文件中读取数据到 pandas DataFrame
File_path = 'salaries.csv'
data_set = pd.read_csv(File_path, index_col=0)

# 获取数据集的样本数量和属性数量
sample_size = len(data_set)
num_attributes = len(data_set.columns)

# 打印样本数量和属性数量
print('样本数量:', sample_size)
print('属性数量:', num_attributes)

# 显示数据集的信息、汇总统计和前几行数据
data_info = data_set.info()
data_describe = data_set.describe()
print(data_describe)
head_data = data_set.head()
first_five_value = data_set.iloc[:5]
print(head_data)
print(first_five_value)

# 访问倒数第二行第三列的特定数值
value = data_set.iloc[-2, 2]
print('特定数值:', value)
# 根据不同条件过滤和查询数据集
print(data_set.loc[1])
print(data_set['salary'] > 190000)
print(data_set[data_set['salary'] > 190000])
print(data_set[data_set['yrs.service'] == 60])
print(data_set[data_set['yrs.since.phd'] >= data_set['yrs.service']])
